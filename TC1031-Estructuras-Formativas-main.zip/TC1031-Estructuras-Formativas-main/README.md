# TC1031_Estructuras_Formativas

Estas actividades son para que practiques la implementación de algoritmos y estructuras de datos. Se basan en las actividades y programas desarrollados en clase, pero tienen pequeñas diferencias para garantizar que no copies y pegues el código ciegamente sin entenderlo.

Cuando tengas que entregar la actividad en canvas por favor solo entrega el archivo.h que lleva el nombre del algoritmo o estructura como se viene en el encabezado del main.

Los cambios que puedes esperar son: 
el manejo de excepciones, 
los casos de prueba, 
los formatos de entrada y salida de algunas funciones.
